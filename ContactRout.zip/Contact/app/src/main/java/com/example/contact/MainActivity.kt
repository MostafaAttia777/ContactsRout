package com.example.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.transition.Visibility
import com.example.contact.databinding.ActivityMainBinding
import com.example.contact.recyclerview.AdapterOfContact
import com.example.contact.recyclerview.Contact_Data
import com.example.contact.recyclerview.delete
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), delete {

    lateinit var binding: ActivityMainBinding
    var fabVisible = false
    lateinit var galleryUri: Any
    lateinit var iamge: ImageView
    lateinit var phone: EditText
    lateinit var email: EditText
    lateinit var adapterOfContact: AdapterOfContact
    lateinit var list: ArrayList<Contact_Data>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fabVisible = false
        binding.contactlist.setOnClickListener {
            if (!fabVisible) {
                binding.addFAB.show()
                binding.addFAB.visibility = View.VISIBLE

                binding.addFAB.setOnClickListener {
                    get_data_by_dialog()
                }
            }
        }

        recycler_works()
    }

    private fun recycler_works() {
        list=ArrayList()
        adapterOfContact=AdapterOfContact(list, this)
        binding.myRcTv.adapter=adapterOfContact
        binding.myRcTv.setHasFixedSize(true)

    }

    private fun get_data_by_dialog() {
        var dialog = AlertDialog.Builder(this)
        var v = layoutInflater.inflate(R.layout.custom_dialog_layout, null)
        dialog.setView(v)
        dialog.create()
        dialog.show()
        var btn = v.findViewById<Button>(R.id.save_data)

        phone = v.findViewById<EditText>(R.id.get_user_phone)
        email = v.findViewById<EditText>(R.id.get_user_email)
        iamge = v.findViewById<ImageView>(R.id.get_image_user)

        iamge.setOnClickListener {
            gelleryLauncher.launch("image/*")
        }
        btn.setOnClickListener {

            var phone_ = phone.text.toString()
            var email_ = email.text.toString()
            var send_bundle = Bundle()
            send_bundle.putString("phone", phone_)
            send_bundle.putString("email", email_)
            send_bundle.putString("image_link", galleryUri.toString())
            var contact = Contact_Data(phone_.toInt(), email_, galleryUri)
            list.add(contact)
            list.add(contact)
            binding.lottieAnimationView.pauseAnimation()
            binding.lottieAnimationView.visibility=View.GONE
            binding.addFAB.hide()

        }
    }

    val gelleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) {
        galleryUri = it!!
        try {
            iamge.setImageURI(it)
        } catch (e: Exception) {

            if (galleryUri == null) {
                Toast.makeText(applicationContext, "select Image", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun deleteitem(index: Int) {
              list.removeAt(index)
        Toast.makeText(applicationContext,"item deleted.",Toast.LENGTH_LONG).show()
    }
}