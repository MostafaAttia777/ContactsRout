package com.example.contact.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.contact.R
import com.example.contact.databinding.CustomlistphonelayoutBinding
import com.squareup.picasso.Picasso

class AdapterOfContact(var list: ArrayList<Contact_Data>,var delete_: delete) :
    RecyclerView.Adapter<AdapterOfContact.Box_VH_holder>() {


    class Box_VH_holder(itemview: View) : ViewHolder(itemview) {
        var bn = CustomlistphonelayoutBinding.bind(itemview)

        var phone = bn.uesrContactPhone
        var email = bn.uesrContactEmail
        var iamge = bn.userContactImage
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Box_VH_holder {
        return Box_VH_holder(
            LayoutInflater.from(parent.context).inflate(R.layout.customlistphonelayout, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: Box_VH_holder, position: Int) {

        var poistion_ = list[position]
        holder.bn.apply {
            holder.phone.text = poistion_.phone.toString()
            holder.email.text = poistion_.email.toString()
            holder.phone.text = poistion_.phone.toString()

            Picasso.get().load(poistion_.iamge.toString()).into(holder.bn.userContactImage)
        }
        holder.bn.uesrContactBtnDelete.setOnClickListener {
            delete_.deleteitem(position)
            notifyDataSetChanged()
        }
        holder.itemView.setOnClickListener {
            Toast.makeText(holder.itemView.context,"welcome ${poistion_.email} ", Toast.LENGTH_LONG).show()

        }

    }
}