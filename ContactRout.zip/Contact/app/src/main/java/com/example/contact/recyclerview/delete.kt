package com.example.contact.recyclerview

interface delete {
    fun deleteitem(index:Int)
}