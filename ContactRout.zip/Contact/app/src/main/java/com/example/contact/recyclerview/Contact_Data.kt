package com.example.contact.recyclerview

data class Contact_Data (

    var phone:Int,
    var email:String,
    var iamge:Any
)